#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

void print_info(void) {
  struct pstat *process_info = malloc(sizeof *process_info);
  getpinfo(process_info);

  printf(1, "PID TICKETS TICKS\n");
  int i;
  for (i = 0; i < NPROC; i++) {
    if (process_info->inuse[i]) {
      printf(1, "%d %d %d\n", process_info->pid[i], process_info->tickets[i], process_info->ticks[i]);
    }
  }
}

int
main(int argc , char **argv)
{
  struct pstat *process_info = malloc(sizeof *process_info);

  if (strcmp(argv[1], "-r") == 0) {
    int i = 0;
    for (;;) {
      if (i < uptime() - 100) {
        i = uptime();
        print_info();
      }
      sleep(1);
    }
  } else {
    print_info();
  }

  free(process_info);

  exit();
}
