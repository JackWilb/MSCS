#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc , char **argv)
{
  // Check for the right number of args
  if(argc < 3){
    printf(2, "usage: tickets <num tickets> <program>\n");
    exit();
  }

  // Syscall to request the desired number of tickets
  int tickets = settickets(atoi(argv[1]));

  // If the syscall failed, exit
  if (tickets == -1) {
    printf(2, "Failed to set tickets value. Make sure it's a positive integer.\n");
    exit();
  }

  // Execute the other program
  exec(argv[2], argv + 2);
  exit();
}
